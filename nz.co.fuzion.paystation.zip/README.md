nz.co.fuzion.paystation
=======================

Paystation payment processor extension for CiviCRM

Note that this processor needs to be upgraded as it still relies on you putting 
the PsIPN.php file in your extern directory - it's on the to-do list

Installation instructions
http://wiki.civicrm.org/confluence/display/CRMDOC40/Extensions+Admin